#pragma once

#include <GL/glew.h>
#include <GL/freeglut.h>
#include "glApplication.h"
#include "glutWindow.h"
#include <iostream>
#include "glsl.h"
#include <time.h>
class Tetera
{
public:
	Tetera() {};
	void dibujarTetera(float x,float y, float z,float red,float green,float blue,float solid);
};

